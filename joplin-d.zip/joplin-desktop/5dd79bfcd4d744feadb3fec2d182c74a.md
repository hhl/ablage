cb0340cb8fc64da8a40498176162b8fa

id: cb0340cb8fc64da8a40498176162b8fa
parent_id: 0d504f3233bb4348a07882ccdec46a2b
item_type: 1
item_id: f284c0aff0ca4ed195ff6734238ec414
item_updated_time: 1623102992220
title_diff: 
body_diff: "@@ -662,12 +662,136 @@\\n BRANCH%3E%0A%60%60%60%0A\\n+%60%60%60%0Agit branch -m farwell farewell%0Agit fetch origin%0Agit branch -u origin/farewell farewell%0Agit remote set-head origin -a%0A%60%60%60\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-06-07T21:57:38.195Z
created_time: 2021-06-07T21:57:38.195Z
type_: 13

id: 5dd79bfcd4d744feadb3fec2d182c74a
parent_id: 3e0adfb4e2484f3ba925e5c78c3702e7
created_time: 2021-06-07T22:27:03.282Z
updated_time: 2023-04-03T19:47:26.421Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551246393
user_created_time: 2021-06-07T22:27:03.282Z
user_updated_time: 2023-04-03T19:47:26.421Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1