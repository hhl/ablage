07c8f37b59ac4bebbc15cf15e0a1a0fd

id: 07c8f37b59ac4bebbc15cf15e0a1a0fd
parent_id: 6f55c3e7c2e64492b90cbad486bb6c1d
item_type: 1
item_id: cdb82781bf9446be8853546c05df8431
item_updated_time: 1612296152743
title_diff: 
body_diff: "@@ -2082,12 +2082,108 @@\\n ot.qcow2%0A%60%60%60\\n+%0A%0A### ein wort aus datei entfernen%0A%60%60%60%0Aecho %22auto=siducer%22 %3E auto%0Ased -i 's/siducer//g' auto%0A%60%60%60\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-02-02T20:09:48.946Z
created_time: 2021-02-02T20:09:48.946Z
type_: 13

id: f85d24fedaef42fca8b11c53da49a5a2
parent_id: 3e0adfb4e2484f3ba925e5c78c3702e7
created_time: 2021-02-04T00:14:08.554Z
updated_time: 2023-04-03T19:47:17.313Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551237286
user_created_time: 2021-02-04T00:14:08.554Z
user_updated_time: 2023-04-03T19:47:17.313Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1