5685c813e0d942de8285d2da2d6b5b51

id: 5685c813e0d942de8285d2da2d6b5b51
parent_id: 
item_type: 1
item_id: 998ccddf0ab147188da404f26efeb941
item_updated_time: 1612195349928
title_diff: "@@ -0,0 +1,7 @@\\n+u-block\\n"
body_diff: "@@ -0,0 +1,111 @@\\n+u-block%0A%0A%60%60%60%0Ayoutube.com##.ytd-popup-container%0Ayoutube.com##.ytd-consent-bump-lightbox%0Ayoutube.com##.opened%0A%60%60%60\\n"
metadata_diff: {"new":{"id":"998ccddf0ab147188da404f26efeb941","parent_id":"1e7ac01f387e44e0bc01da5d3025428c","latitude":"0.00000000","longitude":"0.00000000","altitude":"0.0000","author":"","source_url":"","is_todo":0,"todo_due":0,"todo_completed":0,"source":"joplin-desktop","source_application":"net.cozic.joplin-desktop","application_data":"","order":0,"markup_language":1,"is_shared":0},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-02-01T16:14:33.112Z
created_time: 2021-02-01T16:14:33.112Z
type_: 13

id: 2e6adaf6ccae4d24b2f8b29650bf55ba
parent_id: 3e0adfb4e2484f3ba925e5c78c3702e7
created_time: 2021-02-04T00:14:08.695Z
updated_time: 2023-04-03T19:47:21.116Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551241087
user_created_time: 2021-02-04T00:14:08.695Z
user_updated_time: 2023-04-03T19:47:21.116Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1