c7cc964f04634b059ec0e087460abbe8

id: c7cc964f04634b059ec0e087460abbe8
parent_id: 9a74073685b3426dacf7845edb7293ab
item_type: 1
item_id: 9747015222be47a5a1b57c12be1b99cf
item_updated_time: 1614175405210
title_diff: 
body_diff: "@@ -560,62 +560,8 @@\\n %60%60%60%0A\\n-dpkg -l fonts-noto* %7C grep ii %7C awk '%7Bprint $1,$2,$3%7D'\\n %0Adpk\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-02-24T14:05:10.019Z
created_time: 2021-02-24T14:05:10.019Z
type_: 13

id: efed54e251f344628bcfa1befe55ddef
parent_id: 3e0adfb4e2484f3ba925e5c78c3702e7
created_time: 2021-02-24T14:33:56.072Z
updated_time: 2023-04-03T19:47:26.321Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551246293
user_created_time: 2021-02-24T14:33:56.072Z
user_updated_time: 2023-04-03T19:47:26.321Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1