a2f50296f5a645f3b716712b0cfafa12

id: a2f50296f5a645f3b716712b0cfafa12
parent_id: 
item_type: 1
item_id: 0490209b80844ba0a09f6f1289707668
item_updated_time: 1610032673857
title_diff: "@@ -0,0 +1,22 @@\\n+altes neu installieren\\n"
body_diff: "@@ -0,0 +1,252 @@\\n+# altes neu installieren%0A%0A%60%60%60%0A# dpkg -l *%3Cfoo%3E* %7C grep ii %7C awk '%7Bprint $2%7D' %3E package-selections%0A#%0A# apt install --reinstall $(cat package-selections %7C awk '%7Bprint $1%7D')%0A#%0A# apt install --reinstall $(dpkg -l *%3Cbar%3E* %7C grep ii %7C awk '%7Bprint $2%7D')%0A#%0A%60%60%60\\n"
metadata_diff: {"new":{"id":"0490209b80844ba0a09f6f1289707668","parent_id":"1e7ac01f387e44e0bc01da5d3025428c","latitude":"0.00000000","longitude":"0.00000000","altitude":"0.0000","author":"","source_url":"","is_todo":0,"todo_due":0,"todo_completed":0,"source":"joplin-desktop","source_application":"net.cozic.joplin-desktop","application_data":"","order":0,"markup_language":1,"is_shared":0},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-07T15:17:54.519Z
created_time: 2021-01-07T15:17:54.519Z
type_: 13

id: e0ff7cb5fc484f0c8dddf077ef723ef5
parent_id: 3e0adfb4e2484f3ba925e5c78c3702e7
created_time: 2021-02-04T00:14:13.493Z
updated_time: 2023-04-03T19:47:24.849Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551244826
user_created_time: 2021-02-04T00:14:13.493Z
user_updated_time: 2023-04-03T19:47:24.849Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1