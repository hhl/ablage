20402224d0064191be87b7887bcab036

id: 20402224d0064191be87b7887bcab036
parent_id: b96b5829ca2342699c6bea092e514dc7
item_type: 1
item_id: 55c5acfd372d422493cd3abb6a727ea8
item_updated_time: 1612812433421
title_diff: 
body_diff: "@@ -166,24 +166,31 @@\\n e %22foo%0A%60%60%60%0A%0A\\n+## IWD%0A\\n ### iwctl%0A%0A%60\\n@@ -258,20 +258,20 @@\\n %60%60%60%0A\\n-### \\n+**\\n stop wpa\\n+**\\n %0A%60%60%60\\n@@ -351,20 +351,18 @@\\n ice%0A%60%60%60%0A\\n-### \\n+**\\n start iw\\n@@ -366,11 +366,10 @@\\n  iwd\\n- ##\\n+**\\n %0A%60%60%60\\n@@ -447,9 +447,154 @@\\n .conf**%0A\\n-%0A\\n+%60%60%60%0A%5Bdevice%5D%0Awifi.backend=iwd%0A%60%60%60%0A**/etc/iwd/main.conf**%0A%60%60%60%0A%5BGeneral%5D%0AEnableNetworkConfiguration=true%0A%0A%5BNetwork%5D%0ANameResolvingService=systemd%0A%60%60%60\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-02-08T19:31:22.263Z
created_time: 2021-02-08T19:31:22.263Z
type_: 13

id: 9b19a81e2aad4111baeaeb3c41dcdc95
parent_id: 3e0adfb4e2484f3ba925e5c78c3702e7
created_time: 2021-02-08T19:57:44.427Z
updated_time: 2023-04-03T19:47:18.594Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551238567
user_created_time: 2021-02-08T19:57:44.427Z
user_updated_time: 2023-04-03T19:47:18.594Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1