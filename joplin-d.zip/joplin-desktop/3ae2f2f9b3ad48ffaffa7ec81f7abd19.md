git

Content-Type: text/x-zim-wiki
Wiki-Format: zim 0.6
Creation-Date: 2023-04-03T20:58+02:00

git

====== git ======

===== Arbeiten mit git branch remote =====

'''
git branch -r | grep -v '\\->' | while read remote; do git branch --track "${remote#origin/}" "$remote"; done
'''

'''
git fetch --all
'''

'''
git pull --all
'''

==== git branch remote bekannt machen ====

'''
git checkout -b foo origin/foo
'''

'''
git push origin foo
'''

'''
git push --set-upstream origin c-blues
'''

'''
git pull origin foo
'''

==== git remote branch fetchen ====

'''
$ git branch -r
origin/HEAD -> origin/master
origin/daves_branch
origin/discover
origin/master

$ git fetch origin discover
$ git checkout discover
'''


id: 3ae2f2f9b3ad48ffaffa7ec81f7abd19
parent_id: b7a473ab4dbb4ed5a4223d150faa76d2
created_time: 2023-04-03T18:58:22.981Z
updated_time: 2023-04-03T19:48:03.747Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1680551283719
user_created_time: 2023-04-03T18:58:22.981Z
user_updated_time: 2023-04-03T19:48:03.747Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
share_id: 
conflict_original_id: 
master_key_id: 
type_: 1