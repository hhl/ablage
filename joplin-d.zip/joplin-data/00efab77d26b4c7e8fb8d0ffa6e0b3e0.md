klein helfer

id: 00efab77d26b4c7e8fb8d0ffa6e0b3e0
created_time: 2021-01-07T14:26:06.666Z
updated_time: 2021-01-07T14:26:06.666Z
user_created_time: 2021-01-07T14:26:06.666Z
user_updated_time: 2021-01-07T14:26:06.666Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
parent_id: 
type_: 5