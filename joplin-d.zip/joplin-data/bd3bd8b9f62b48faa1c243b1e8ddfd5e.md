id: bd3bd8b9f62b48faa1c243b1e8ddfd5e
parent_id: daddfc0f407b44ad9a8cca79b8314bba
item_type: 1
item_id: 00c88dd1fc0d45c48e3794c5247ff245
item_updated_time: 1610574793694
title_diff: 
body_diff: 
metadata_diff: {"new":{"order":1610033786694},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-19T22:47:52.516Z
created_time: 2021-01-19T22:47:52.516Z
type_: 13