WebClipper.png

id: b24f8da4b40e4a2e9b1bd1f5ea98a3aa
mime: image/png
filename: 
created_time: 2021-01-07T13:27:55.438Z
updated_time: 2021-01-07T13:27:55.438Z
user_created_time: 2021-01-07T13:27:55.438Z
user_updated_time: 2021-01-07T13:27:55.438Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 8894
is_shared: 0
type_: 4