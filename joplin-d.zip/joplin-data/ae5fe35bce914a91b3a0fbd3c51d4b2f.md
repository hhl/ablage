id: ae5fe35bce914a91b3a0fbd3c51d4b2f
parent_id: 0a0905790d9d4b41a79933c2a37469ca
item_type: 1
item_id: 1ac38f9ec8214b7d9e57159555bb145a
item_updated_time: 1610038919067
title_diff: 
body_diff: "@@ -47,11 +47,11 @@\\n %0A%60%60%60\\n-%0A# \\n+sh%0A\\n shut\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-07T17:02:37.786Z
created_time: 2021-01-07T17:02:37.786Z
type_: 13