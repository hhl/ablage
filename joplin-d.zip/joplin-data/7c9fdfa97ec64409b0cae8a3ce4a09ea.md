id: 7c9fdfa97ec64409b0cae8a3ce4a09ea
note_id: 4f0f78382ccb4598b254bb88a2751b4f
tag_id: 13bccc2b28184de39f5656f8cf109592
created_time: 2021-01-19T22:53:36.165Z
updated_time: 2021-01-19T22:53:36.165Z
user_created_time: 2021-01-19T22:53:36.165Z
user_updated_time: 2021-01-19T22:53:36.165Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
type_: 6