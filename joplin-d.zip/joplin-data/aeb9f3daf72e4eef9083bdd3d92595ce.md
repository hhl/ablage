id: aeb9f3daf72e4eef9083bdd3d92595ce
note_id: 05619af6dc624d1590c78d47cda9146e
tag_id: f45056649e4a4cbbb37f395d368b2325
created_time: 2023-02-06T16:29:19.448Z
updated_time: 2023-02-06T16:29:19.448Z
user_created_time: 2023-02-06T16:29:19.448Z
user_updated_time: 2023-02-06T16:29:19.448Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
type_: 6