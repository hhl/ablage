id: daddfc0f407b44ad9a8cca79b8314bba
parent_id: a46649dd75b54a3fa40f953b5f8a98d2
item_type: 1
item_id: 00c88dd1fc0d45c48e3794c5247ff245
item_updated_time: 1610574793694
title_diff: 
body_diff: "@@ -3,19 +3,24 @@\\n imwheel%0A\\n+%0A\\n %60%60%60\\n+bash\\n %0A#%0Axprop\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-19T14:37:55.462Z
created_time: 2021-01-19T14:37:55.462Z
type_: 13