id: f13acf6ff6e54eaa8676f2bed0cfc17a
parent_id: 
item_type: 1
item_id: edc891d4b6f3419dafdd4b660576cf4a
item_updated_time: 1610546918239
title_diff: "@@ -0,0 +1,6 @@\\n+google\\n"
body_diff: "@@ -0,0 +1,70 @@\\n+google%0A%0A4/1AY0e-g7Fe54oWyu_laAQYfa7hzZyJ8jUkmVi63wLwxpaXsCXjdTstii1kVA\\n"
metadata_diff: {"new":{"id":"edc891d4b6f3419dafdd4b660576cf4a","parent_id":"1e7ac01f387e44e0bc01da5d3025428c","latitude":"0.00000000","longitude":"0.00000000","altitude":"0.0000","author":"","source_url":"","is_todo":0,"todo_due":0,"todo_completed":0,"source":"joplin-desktop","source_application":"net.cozic.joplin-desktop","application_data":"","order":0,"markup_language":1,"is_shared":0},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-13T14:18:16.775Z
created_time: 2021-01-13T14:18:16.775Z
type_: 13