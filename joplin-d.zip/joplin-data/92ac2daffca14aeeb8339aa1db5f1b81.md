id: 92ac2daffca14aeeb8339aa1db5f1b81
parent_id: 
item_type: 1
item_id: 9747015222be47a5a1b57c12be1b99cf
item_updated_time: 1610033552238
title_diff: "@@ -0,0 +1,22 @@\\n+dpkg Ausgabe leserlich\\n"
body_diff: "@@ -0,0 +1,396 @@\\n+# dpkg Ausgabe leserlich%0A%60%60%60%0A#%0A# dpkg -l *cups* %7C grep ii %7C awk '%7Bprint $2,$3%7D' %7C column -t%0A#%0A# dpkg -l *icon* *qml* *plasma* %7C grep ii %7C awk '%7Bprint $2%7D' %7C sed 's/:amd64//g'%7C column -t%0A#%0A# dpkg -l *icon* *qml* *plasma* *kf5* *kde* %7C grep ii %7C awk '%7Bprint $2%7D' %7C sed 's/:amd64//g'%7C sed 's/%5Elib*//g' %7C column -t%0A#%0A%60%60%60%0A---%0A%60%60%60%0A# dpkg --get-selections %7C grep openjdk-11-jre-headless %7C cut -f 1%0A%60%60%60%0A%0A\\n"
metadata_diff: {"new":{"id":"9747015222be47a5a1b57c12be1b99cf","parent_id":"1e7ac01f387e44e0bc01da5d3025428c","latitude":"0.00000000","longitude":"0.00000000","altitude":"0.0000","author":"","source_url":"","is_todo":0,"todo_due":0,"todo_completed":0,"source":"joplin-desktop","source_application":"net.cozic.joplin-desktop","application_data":"","order":0,"markup_language":1,"is_shared":0},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-07T15:37:54.349Z
created_time: 2021-01-07T15:37:54.349Z
type_: 13