id: f21a3ef793664facb04cadaf531acfcc
parent_id: 17c0cd5483014b49b2f4bfa2365fda6d
item_type: 1
item_id: 05619af6dc624d1590c78d47cda9146e
item_updated_time: 1610035673358
title_diff: 
body_diff: "@@ -320,8 +320,163 @@\\n  liste%0A#\\n+%0A%60%60%60%0A#### noch%0A%0A%60%60%60%0A# aptitude -s purge %60dpkg --get-selections %7C grep openjdk-11-jre-headless %7C cut -f 1%C2%B4    %0A%60%60%60%0A**then run**%0A%0A%60%60%60%0Aaptitude -f install%0A%60%60%60\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-07T16:07:54.374Z
created_time: 2021-01-07T16:07:54.374Z
type_: 13