id: 07c8f37b59ac4bebbc15cf15e0a1a0fd
parent_id: 6f55c3e7c2e64492b90cbad486bb6c1d
item_type: 1
item_id: cdb82781bf9446be8853546c05df8431
item_updated_time: 1612296152743
title_diff: 
body_diff: "@@ -2082,12 +2082,108 @@\\n ot.qcow2%0A%60%60%60\\n+%0A%0A### ein wort aus datei entfernen%0A%60%60%60%0Aecho %22auto=siducer%22 %3E auto%0Ased -i 's/siducer//g' auto%0A%60%60%60\\n"
metadata_diff: {"new":{},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-02-02T20:09:48.946Z
created_time: 2021-02-02T20:09:48.946Z
type_: 13