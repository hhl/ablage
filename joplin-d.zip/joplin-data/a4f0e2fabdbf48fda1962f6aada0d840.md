id: a4f0e2fabdbf48fda1962f6aada0d840
parent_id: d316fd1f345a41ec82f9e5003d61a31d
item_type: 1
item_id: 05619af6dc624d1590c78d47cda9146e
item_updated_time: 1611097386384
title_diff: "@@ -1,5 +1,5 @@\\n-a\\n+A\\n ufr%C3%A4\\n"
body_diff: "@@ -1,11 +1,11 @@\\n # \\n-a\\n+A\\n ufr%C3%A4umen\\n@@ -28,16 +28,17 @@\\n adikal%0A%0A\\n+%0A\\n %60%60%60%0Adpkg\\n@@ -145,23 +145,14 @@\\n all)\\n+%0A\\n %60%60%60\\n- %0A---%0A%0A#### \\n+%0A%0A\\n weit\\n@@ -197,24 +197,25 @@\\n  entfernen%0A%0A\\n+%0A\\n %60%60%60%0Aapt-get \\n@@ -255,16 +255,24 @@\\n t $2%7D')%0A\\n+%60%60%60%0A%0A%60%60%60\\n %0Adpkg -l\\n@@ -308,16 +308,17 @@\\n ste%0A%60%60%60%0A\\n+%0A\\n #### noc\\n@@ -468,12 +468,13 @@\\n  install%0A%60%60%60\\n+%0A\\n"
metadata_diff: {"new":{"order":1610031459902},"deleted":[]}
encryption_cipher_text: 
encryption_applied: 0
updated_time: 2021-01-19T23:07:52.481Z
created_time: 2021-01-19T23:07:52.481Z
type_: 13