apt

# apt

## do not remove the kernel automatically

Automatically remove unused kernels on apt {dist,full}-upgrade. To revert  to previous behavior, set APT::Get::AutomaticRemove::Kernels to false or  pass --no-auto-remove to the command. apt-get remains unchanged.

```
:~$ cat /etc/apt/apt.conf

# stop autremove to yell around
APT::Get::AutomaticRemove 0;
APT::Get::HideAutoRemove 1;
# do not remove kernels automaticly
APT::Get::AutomaticRemove::Kernels false;
```
Päckchen behalten
```
/etc/apt/apt.conf.d$ cat 01keep-debs
APT::Keep-Downloaded-Packages "true";
```


id: fdbf4d972e7e4f1e8ee7cee696dd4e06
parent_id: 1e7ac01f387e44e0bc01da5d3025428c
created_time: 2021-01-08T23:46:14.493Z
updated_time: 2021-01-20T18:20:00.310Z
is_conflict: 0
latitude: 0.00000000
longitude: 0.00000000
altitude: 0.0000
author: 
source_url: 
is_todo: 0
todo_due: 0
todo_completed: 0
source: joplin-desktop
source_application: net.cozic.joplin-desktop
application_data: 
order: 1610149574493
user_created_time: 2021-01-08T23:46:14.493Z
user_updated_time: 2021-01-20T18:20:00.310Z
encryption_cipher_text: 
encryption_applied: 0
markup_language: 1
is_shared: 0
type_: 1